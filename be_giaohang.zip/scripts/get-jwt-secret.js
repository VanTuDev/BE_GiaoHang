import config from '../config/config.js';

// In ra JWT_SECRET hiện tại (đã load từ .env nếu có)
console.log(config.jwtSecret);


